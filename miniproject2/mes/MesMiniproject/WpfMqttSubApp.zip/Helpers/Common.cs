﻿namespace WpfMqttSubApp.Helpers
{
    public class Common
    {
        // DB연결문자열을 한군데 저장(이거 안씀)
        public static readonly string CONNSTR = "Server=127.0.0.1;Database=moviefinder;Uid=root;Pwd=12345;Charset=utf8";
    }
}
